use sys;
drop table virat_scores

create table sachin_scores (
seq_no int,
mtch_date varchar(20),
versus varchar(100),
venue varchar(100),
dismissal_mode varchar(200),
runs int,
balls int
);

create table virat_scores (
seq_no int,
mtch_date varchar(20),
versus varchar(100),
venue varchar(100),
dismissal_mode varchar(200),
runs int,
balls int
);

select * from sachin_scores

select * from virat_scores